# practice-repository
Jake's Eatery Activity
This is the GitHub Repository for the curriculum for the UX/UI bootcamp
